import { Router, Request, Response, NextFunction } from "express";
import { pool } from "../db/pool";

const router = Router();

// ── Vehiculos ─────────────────────────────────────────────────

// GET /api/logistics/vehiculos?brand=&estado=
/**
 * @swagger
 * /logistics/vehiculos:
 *   get:
 *     summary: Listar vehículos
 *     tags: [Logistics]
 *     parameters:
 *       - in: query
 *         name: brand
 *         schema: { $ref: '#/components/schemas/Brand' }
 *       - in: query
 *         name: estado
 *         schema: { type: string }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items: { $ref: '#/components/schemas/Vehiculo' }
 */
router.get("/vehiculos", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { estado, brand } = req.query;
    const conditions: string[] = [];
    const values: unknown[] = [];

    if (estado) { conditions.push(`v.estado = $${values.length + 1}`); values.push(estado); }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

    // If filtering by brand, join vehiculo_marcas
    let query: string;
    if (brand) {
      query = `
        SELECT v.*,
               COALESCE(
                 json_agg(vm.brand ORDER BY vm.brand) FILTER (WHERE vm.brand IS NOT NULL),
                 '[]'
               ) AS marcas_asignadas
        FROM vehiculos v
        LEFT JOIN vehiculo_marcas vm ON vm.vehiculo_id = v.id
        WHERE vm.brand = $${values.length + 1}
        ${estado ? `AND v.estado = $1` : ""}
        GROUP BY v.id
        ORDER BY v.id`;
      values.push(brand);
    } else {
      query = `
        SELECT v.*,
               COALESCE(
                 json_agg(vm.brand ORDER BY vm.brand) FILTER (WHERE vm.brand IS NOT NULL),
                 '[]'
               ) AS marcas_asignadas
        FROM vehiculos v
        LEFT JOIN vehiculo_marcas vm ON vm.vehiculo_id = v.id
        ${where}
        GROUP BY v.id
        ORDER BY v.id`;
    }

    const { rows } = await pool.query(query, values);
    res.json(rows);
  } catch (err) { next(err); }
});

// GET /api/logistics/vehiculos/:id
/**
 * @swagger
 * /logistics/vehiculos/{id}:
 *   get:
 *     summary: Obtener vehículo por ID
 *     tags: [Logistics]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Vehiculo' }
 *       404:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
router.get("/vehiculos/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const [v, marcas] = await Promise.all([
      pool.query("SELECT * FROM vehiculos WHERE id = $1", [req.params.id]),
      pool.query("SELECT brand FROM vehiculo_marcas WHERE vehiculo_id = $1", [req.params.id]),
    ]);
    if (!v.rows.length) { res.status(404).json({ error: "Vehiculo not found" }); return; }
    res.json({ ...v.rows[0], marcas_asignadas: marcas.rows.map((r) => r.brand) });
  } catch (err) { next(err); }
});

// POST /api/logistics/vehiculos
/**
 * @swagger
 * /logistics/vehiculos:
 *   post:
 *     summary: Crear vehículo
 *     tags: [Logistics]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/Vehiculo' }
 *     responses:
 *       201:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Vehiculo' }
 */
router.post("/vehiculos", async (req: Request, res: Response, next: NextFunction) => {
  const client = await pool.connect();
  try {
    const { placa, modelo, marca, estado, ultimo_mantenimiento, fecha_vencimiento_soat, marcas_asignadas } = req.body;
    if (!placa) { res.status(400).json({ error: "placa is required" }); return; }

    await client.query("BEGIN");
    const { rows } = await client.query(
      `INSERT INTO vehiculos (placa, modelo, marca, estado, ultimo_mantenimiento, fecha_vencimiento_soat)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [placa, modelo ?? null, marca ?? null,
       estado ?? "disponible", ultimo_mantenimiento ?? null, fecha_vencimiento_soat ?? null]
    );
    const vehiculo = rows[0];

    if (Array.isArray(marcas_asignadas)) {
      for (const b of marcas_asignadas) {
        await client.query(
          "INSERT INTO vehiculo_marcas (vehiculo_id, brand) VALUES ($1, $2) ON CONFLICT DO NOTHING",
          [vehiculo.id, b]
        );
      }
    }

    await client.query("COMMIT");
    const [vRes, mRes] = await Promise.all([
      pool.query("SELECT * FROM vehiculos WHERE id = $1", [vehiculo.id]),
      pool.query("SELECT brand FROM vehiculo_marcas WHERE vehiculo_id = $1", [vehiculo.id]),
    ]);
    res.status(201).json({ ...vRes.rows[0], marcas_asignadas: mRes.rows.map((r) => r.brand) });
  } catch (err) {
    await client.query("ROLLBACK");
    next(err);
  } finally {
    client.release();
  }
});

// PUT /api/logistics/vehiculos/:id
router.put("/vehiculos/:id", async (req: Request, res: Response, next: NextFunction) => {
  const client = await pool.connect();
  try {
    const id = Number(req.params.id);
    const { placa, modelo, marca, estado, ultimo_mantenimiento, fecha_vencimiento_soat, marcas_asignadas } = req.body;

    await client.query("BEGIN");
    const { rows } = await client.query(
      `UPDATE vehiculos
       SET placa                  = COALESCE($1, placa),
           modelo                 = COALESCE($2, modelo),
           marca                  = COALESCE($3, marca),
           estado                 = COALESCE($4, estado),
           ultimo_mantenimiento   = COALESCE($5, ultimo_mantenimiento),
           fecha_vencimiento_soat = COALESCE($6, fecha_vencimiento_soat)
       WHERE id = $7 RETURNING *`,
      [placa ?? null, modelo ?? null, marca ?? null,
       estado ?? null, ultimo_mantenimiento ?? null, fecha_vencimiento_soat ?? null, id]
    );
    if (!rows.length) {
      await client.query("ROLLBACK");
      res.status(404).json({ error: "Vehiculo not found" }); return;
    }

    if (Array.isArray(marcas_asignadas)) {
      await client.query("DELETE FROM vehiculo_marcas WHERE vehiculo_id = $1", [id]);
      for (const b of marcas_asignadas) {
        await client.query(
          "INSERT INTO vehiculo_marcas (vehiculo_id, brand) VALUES ($1, $2) ON CONFLICT DO NOTHING",
          [id, b]
        );
      }
    }

    await client.query("COMMIT");
    const mRes = await pool.query("SELECT brand FROM vehiculo_marcas WHERE vehiculo_id = $1", [id]);
    res.json({ ...rows[0], marcas_asignadas: mRes.rows.map((r) => r.brand) });
  } catch (err) {
    await client.query("ROLLBACK");
    next(err);
  } finally {
    client.release();
  }
});

// DELETE /api/logistics/vehiculos/:id
router.delete("/vehiculos/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { rows } = await pool.query("DELETE FROM vehiculos WHERE id = $1 RETURNING id", [req.params.id]);
    if (!rows.length) { res.status(404).json({ error: "Vehiculo not found" }); return; }
    res.json({ deleted: rows[0].id });
  } catch (err) { next(err); }
});

// ── Asignaciones ──────────────────────────────────────────────
/**
 * @swagger
 * /logistics/vehiculos/{id}:
 *   put:
 *     summary: Actualizar vehículo
 *     tags: [Logistics]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/Vehiculo' }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Vehiculo' }
 */
/**
 * @swagger
 * /logistics/vehiculos/{id}:
 *   delete:
 *     summary: Eliminar vehículo
 *     tags: [Logistics]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 deleted: { type: integer }
 */
/**
 * @swagger
 * /logistics/asignaciones:
 *   get:
 *     summary: Listar asignaciones
 *     tags: [Logistics]
 *     parameters:
 *       - in: query
 *         name: fecha
 *         schema: { type: string, format: date }
 *       - in: query
 *         name: estado
 *         schema: { type: string }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items: { $ref: '#/components/schemas/Asignacion' }
 */

// GET /api/logistics/asignaciones?fecha=&estado=
router.get("/asignaciones", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { fecha, estado } = req.query;
    const conditions: string[] = [];
    const values: unknown[] = [];

    if (fecha)  { conditions.push(`a.fecha  = $${values.length + 1}`); values.push(fecha); }
    if (estado) { conditions.push(`a.estado = $${values.length + 1}`); values.push(estado); }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

    const { rows } = await pool.query(
      `SELECT a.*,
              row_to_json(ch.*) AS chofer,
              row_to_json(v.*)  AS vehiculo,
              COALESCE(
                json_agg(af.ficha_id ORDER BY af.ficha_id) FILTER (WHERE af.ficha_id IS NOT NULL),
                '[]'
              ) AS fichas_ids
       FROM asignaciones a
       LEFT JOIN personal ch ON ch.id = a.chofer_id
       LEFT JOIN vehiculos v  ON v.id  = a.vehiculo_id
       LEFT JOIN asignacion_fichas af ON af.asignacion_id = a.id
       ${where}
       GROUP BY a.id, ch.id, v.id
       ORDER BY a.fecha DESC, a.id DESC`,
      values
    );
    res.json(rows);
  } catch (err) { next(err); }
});

// GET /api/logistics/asignaciones/:id
router.get("/asignaciones/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { rows } = await pool.query(
      `SELECT a.*,
              row_to_json(ch.*) AS chofer,
              row_to_json(v.*)  AS vehiculo,
              COALESCE(
                json_agg(af.ficha_id ORDER BY af.ficha_id) FILTER (WHERE af.ficha_id IS NOT NULL),
                '[]'
              ) AS fichas_ids
       FROM asignaciones a
       LEFT JOIN personal ch ON ch.id = a.chofer_id
       LEFT JOIN vehiculos v  ON v.id  = a.vehiculo_id
       LEFT JOIN asignacion_fichas af ON af.asignacion_id = a.id
       WHERE a.id = $1
       GROUP BY a.id, ch.id, v.id`,
      [req.params.id]
    );
    if (!rows.length) { res.status(404).json({ error: "Asignacion not found" }); return; }
    res.json(rows[0]);
  } catch (err) { next(err); }
});

// POST /api/logistics/asignaciones
/**
 * @swagger
 * /logistics/asignaciones/{id}:
 *   get:
 *     summary: Obtener asignación por ID
 *     tags: [Logistics]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Asignacion' }
 *       404:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
/**
 * @swagger
 * /logistics/asignaciones:
 *   post:
 *     summary: Crear asignación
 *     tags: [Logistics]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/Asignacion' }
 *     responses:
 *       201:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Asignacion' }
 */
router.post("/asignaciones", async (req: Request, res: Response, next: NextFunction) => {
  const client = await pool.connect();
  try {
    const { chofer_id, vehiculo_id, fecha, ruta, entregas, estado, fichas_ids } = req.body;
    if (!fecha) { res.status(400).json({ error: "fecha is required" }); return; }

    await client.query("BEGIN");
    const { rows } = await client.query(
      `INSERT INTO asignaciones (chofer_id, vehiculo_id, fecha, ruta, entregas, estado)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [chofer_id ?? null, vehiculo_id ?? null, fecha,
       ruta ?? null, entregas ?? 0, estado ?? "programada"]
    );
    const asignacion = rows[0];

    if (Array.isArray(fichas_ids)) {
      for (const fid of fichas_ids) {
        await client.query(
          "INSERT INTO asignacion_fichas (asignacion_id, ficha_id) VALUES ($1, $2) ON CONFLICT DO NOTHING",
          [asignacion.id, fid]
        );
      }
    }

    await client.query("COMMIT");
    res.status(201).json(asignacion);
  } catch (err) {
    await client.query("ROLLBACK");
    next(err);
  } finally {
    client.release();
  }
});

// PUT /api/logistics/asignaciones/:id
/**
 * @swagger
 * /logistics/asignaciones/{id}:
 *   put:
 *     summary: Actualizar asignación
 *     tags: [Logistics]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/Asignacion' }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Asignacion' }
 */
router.put("/asignaciones/:id", async (req: Request, res: Response, next: NextFunction) => {
  const client = await pool.connect();
  try {
    const id = Number(req.params.id);
    const { chofer_id, vehiculo_id, fecha, ruta, entregas, estado, fichas_ids } = req.body;

    await client.query("BEGIN");
    const { rows } = await client.query(
      `UPDATE asignaciones
       SET chofer_id   = COALESCE($1, chofer_id),
           vehiculo_id = COALESCE($2, vehiculo_id),
           fecha       = COALESCE($3, fecha),
           ruta        = COALESCE($4, ruta),
           entregas    = COALESCE($5, entregas),
           estado      = COALESCE($6, estado)
       WHERE id = $7 RETURNING *`,
      [chofer_id ?? null, vehiculo_id ?? null, fecha ?? null,
       ruta ?? null, entregas ?? null, estado ?? null, id]
    );
    if (!rows.length) {
      await client.query("ROLLBACK");
      res.status(404).json({ error: "Asignacion not found" }); return;
    }

    if (Array.isArray(fichas_ids)) {
      await client.query("DELETE FROM asignacion_fichas WHERE asignacion_id = $1", [id]);
      for (const fid of fichas_ids) {
        await client.query(
          "INSERT INTO asignacion_fichas (asignacion_id, ficha_id) VALUES ($1, $2) ON CONFLICT DO NOTHING",
          [id, fid]
        );
      }
    }

    await client.query("COMMIT");
    res.json(rows[0]);
  } catch (err) {
    await client.query("ROLLBACK");
    next(err);
  } finally {
    client.release();
  }
});

// DELETE /api/logistics/asignaciones/:id
/**
 * @swagger
 * /logistics/asignaciones/{id}:
 *   delete:
 *     summary: Eliminar asignación
 *     tags: [Logistics]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 deleted: { type: integer }
 */
router.delete("/asignaciones/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { rows } = await pool.query(
      "DELETE FROM asignaciones WHERE id = $1 RETURNING id", [req.params.id]
    );
    if (!rows.length) { res.status(404).json({ error: "Asignacion not found" }); return; }
    res.json({ deleted: rows[0].id });
  } catch (err) { next(err); }
});

export default router;
