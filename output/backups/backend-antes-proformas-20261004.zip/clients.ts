import { Router, Request, Response, NextFunction } from "express";
import { pool } from "../db/pool";

const router = Router();

function normalizeOptionalText(value: unknown) {
  if (value === undefined || value === null) return null;
  if (typeof value !== "string") return value;
  const trimmed = value.trim();
  return trimmed === "" ? null : trimmed;
}

// ── GET /api/clients?brand=&status= ──────────────────────────
/**
 * @swagger
 * /clients:
 *   get:
 *     summary: Listar clientes
 *     tags: [Clients]
 *     parameters:
 *       - in: query
 *         name: brand
 *         schema: { $ref: '#/components/schemas/Brand' }
 *       - in: query
 *         name: status
 *         schema: { type: string }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items: { $ref: '#/components/schemas/Client' }
 */
router.get("/", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { brand, status } = req.query;
    const conditions: string[] = [];
    const values: unknown[] = [];

    if (brand) {
      conditions.push(`creado_por = $${values.length + 1}`);
      values.push(brand);
    }
    if (status) {
      conditions.push(`status = $${values.length + 1}`);
      values.push(status);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

    const { rows } = await pool.query(
      `SELECT c.*, c.status AS estado,
              COALESCE((SELECT COUNT(*) FROM fichas f WHERE f.cliente_id = c.id), 0) AS fichas_reales,
              c.fichas_base + COALESCE((SELECT COUNT(*) FROM fichas f WHERE f.cliente_id = c.id), 0) AS total_fichas
       FROM clients c
       ${where}
       ORDER BY c.created_at DESC`,
      values
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

// ── GET /api/clients/:id ──────────────────────────────────────
/**
 * @swagger
 * /clients/{id}:
 *   get:
 *     summary: Obtener cliente por ID
 *     tags: [Clients]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Client' }
 *       404:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Error' }
 */
router.get("/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { rows } = await pool.query(
      `SELECT c.*, c.status AS estado,
              COALESCE((SELECT COUNT(*) FROM fichas f WHERE f.cliente_id = c.id), 0) AS fichas_reales,
              c.fichas_base + COALESCE((SELECT COUNT(*) FROM fichas f WHERE f.cliente_id = c.id), 0) AS total_fichas
       FROM clients c WHERE c.id = $1`,
      [req.params.id]
    );
    if (!rows.length) { res.status(404).json({ error: "Client not found" }); return; }
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
});

// ── POST /api/clients ─────────────────────────────────────────
/**
 * @swagger
 * /clients:
 *   post:
 *     summary: Crear cliente
 *     tags: [Clients]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/Client' }
 *     responses:
 *       201:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Client' }
 */
router.post("/", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const {
      nombre,
      razon_social,
      dni_ruc,
      email,
      telefono,
      direccion,
      ciudad,
      canal,
      status,
      creado_por,
      anio_registro,
      fichas_base,
      recomendaciones,
    } = req.body;

    const nombreValue = typeof nombre === "string" ? nombre.trim() : "";
    if (!nombreValue || !creado_por) {
      res.status(400).json({ error: "nombre and creado_por are required" });
      return;
    }

    const { rows } = await pool.query(
      `INSERT INTO clients (nombre, razon_social, dni_ruc, email, telefono, direccion, ciudad, canal, status, creado_por, anio_registro, fichas_base, recomendaciones)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
       RETURNING *, status AS estado, 0 AS fichas_reales, fichas_base AS total_fichas`,
      [
        nombreValue,
        normalizeOptionalText(razon_social),
        normalizeOptionalText(dni_ruc),
        normalizeOptionalText(email),
        normalizeOptionalText(telefono),
        normalizeOptionalText(direccion),
        normalizeOptionalText(ciudad),
        normalizeOptionalText(canal),
        normalizeOptionalText(status) ?? "active",
        creado_por,
        anio_registro ?? null,
        Number.isFinite(Number(fichas_base)) ? Number(fichas_base) : 0,
        Number.isFinite(Number(recomendaciones)) ? Number(recomendaciones) : 0,
      ]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
});

// ── PUT /api/clients/:id ──────────────────────────────────────
/**
 * @swagger
 * /clients/{id}:
 *   put:
 *     summary: Actualizar cliente
 *     tags: [Clients]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/Client' }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Client' }
 */
router.put("/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { nombre, razon_social, dni_ruc, email, telefono, direccion, ciudad, canal, status, anio_registro, fichas_base, recomendaciones } = req.body;

    if (nombre !== undefined && typeof nombre === "string" && !nombre.trim()) {
      res.status(400).json({ error: "nombre cannot be empty" });
      return;
    }

    const hasAnioRegistro = Object.prototype.hasOwnProperty.call(req.body, "anio_registro");
    const hasFichasBase = Object.prototype.hasOwnProperty.call(req.body, "fichas_base");
    const hasRecomendaciones = Object.prototype.hasOwnProperty.call(req.body, "recomendaciones");

    const { rows } = await pool.query(
      `UPDATE clients
       SET nombre    = COALESCE($1, nombre),
           razon_social = CASE WHEN $2::boolean THEN $3 ELSE razon_social END,
           dni_ruc   = CASE WHEN $4::boolean THEN $5 ELSE dni_ruc END,
           email     = COALESCE($6, email),
           telefono  = COALESCE($7, telefono),
           -- Opcionales: si vienen en el cuerpo se guardan tal cual (vacío = se borra); si no vienen, no se tocan
           direccion = CASE WHEN $20::boolean THEN $8 ELSE direccion END,
           ciudad    = CASE WHEN $21::boolean THEN $9 ELSE ciudad END,
           canal     = CASE WHEN $19::boolean THEN $10 ELSE canal END,
           status    = COALESCE($11, status),
           anio_registro   = CASE WHEN $13::boolean THEN $14::int ELSE anio_registro END,
           fichas_base     = CASE WHEN $15::boolean THEN $16::int ELSE fichas_base END,
           recomendaciones = CASE WHEN $17::boolean THEN $18::int ELSE recomendaciones END
       WHERE id = $12 RETURNING *, status AS estado,
             (SELECT COUNT(*) FROM fichas f WHERE f.cliente_id = clients.id) AS fichas_reales,
             fichas_base + (SELECT COUNT(*) FROM fichas f WHERE f.cliente_id = clients.id) AS total_fichas`,
      [
        typeof nombre === "string" ? nombre.trim() : null,
        Object.prototype.hasOwnProperty.call(req.body, "razon_social"),
        normalizeOptionalText(razon_social),
        Object.prototype.hasOwnProperty.call(req.body, "dni_ruc"),
        normalizeOptionalText(dni_ruc),
        normalizeOptionalText(email),
        normalizeOptionalText(telefono),
        normalizeOptionalText(direccion),
        normalizeOptionalText(ciudad),
        normalizeOptionalText(canal),
        normalizeOptionalText(status),
        req.params.id,
        hasAnioRegistro,
        anio_registro ?? null,
        hasFichasBase,
        fichas_base ?? null,
        hasRecomendaciones,
        recomendaciones ?? null,
        Object.prototype.hasOwnProperty.call(req.body, "canal"),
        Object.prototype.hasOwnProperty.call(req.body, "direccion"),
        Object.prototype.hasOwnProperty.call(req.body, "ciudad"),
      ]
    );
    if (!rows.length) { res.status(404).json({ error: "Client not found" }); return; }
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
});

// ── DELETE /api/clients/:id ───────────────────────────────────
/**
 * @swagger
 * /clients/{id}:
 *   delete:
 *     summary: Eliminar cliente
 *     tags: [Clients]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 deleted: { type: integer }
 */
router.delete("/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { rows } = await pool.query(
      "DELETE FROM clients WHERE id = $1 RETURNING id",
      [req.params.id]
    );
    if (!rows.length) { res.status(404).json({ error: "Client not found" }); return; }
    res.json({ deleted: rows[0].id });
  } catch (err) {
    next(err);
  }
});

export default router;
