import { Router, Request, Response, NextFunction } from "express";
import type { Pool, PoolClient } from "pg";
import { pool } from "../db/pool";

const router = Router();

// ── Helpers ───────────────────────────────────────────────────

async function getInflablesIncluidos(paqueteId: number) {
  const { rows } = await pool.query(
    `SELECT slot, cantidad, array_agg(tipo_id ORDER BY tipo_id) AS tipo_ids
     FROM paquete_inflables_incluidos
     WHERE paquete_id = $1
     GROUP BY slot, cantidad
     ORDER BY slot`,
    [paqueteId]
  );
  return rows.map((r) => ({ tipo_ids: r.tipo_ids, cantidad: r.cantidad }));
}

async function setInflablesIncluidos(
  client: Pool | PoolClient,
  paqueteId: number,
  inflablesIncluidos: unknown
) {
  await client.query("DELETE FROM paquete_inflables_incluidos WHERE paquete_id = $1", [paqueteId]);
  if (!Array.isArray(inflablesIncluidos)) return;

  let slot = 0;
  for (const grupo of inflablesIncluidos) {
    slot += 1;
    const tipoIds: unknown[] = Array.isArray(grupo?.tipo_ids) ? grupo.tipo_ids : [];
    const cantidad = Number(grupo?.cantidad) || 1;
    for (const tipoId of tipoIds) {
      await client.query(
        `INSERT INTO paquete_inflables_incluidos (paquete_id, slot, tipo_id, cantidad)
         VALUES ($1, $2, $3, $4)`,
        [paqueteId, slot, tipoId, cantidad]
      );
    }
  }
}

async function getPaqueteWithItems(id: number) {
  const [paquete, items, inflablesIncluidos] = await Promise.all([
    pool.query(
      `SELECT id, nombre, precio_unitario, tipo, brand, created_at
       FROM paquetes
       WHERE id = $1`,
      [id]
    ),
    pool.query(
      "SELECT * FROM paquete_items WHERE paquete_id = $1 ORDER BY id",
      [id]
    ),
    getInflablesIncluidos(id),
  ]);
  if (!paquete.rows.length) return null;
  return { ...paquete.rows[0], contenido: items.rows, inflables_incluidos: inflablesIncluidos };
}

// GET /api/paquetes?brand=&tipo=
router.get("/", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const conditions: string[] = [];
    const values: unknown[] = [];

    if (req.query.brand) {
      conditions.push(`p.brand = $${values.length + 1}`);
      values.push(req.query.brand);
    }
    if (req.query.tipo) {
      conditions.push(`p.tipo = $${values.length + 1}`);
      values.push(req.query.tipo);
    }

    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

    const { rows } = await pool.query(
      `SELECT p.id,
              p.nombre,
              p.precio_unitario,
              p.tipo,
              p.brand,
              p.created_at,
              COALESCE(
                json_agg(
                  json_build_object(
                    'id', pi.id,
                    'producto_sku', pi.producto_sku,
                    'producto_nombre', pi.producto_nombre,
                    'cantidad', pi.cantidad
                  ) ORDER BY pi.id
                ) FILTER (WHERE pi.id IS NOT NULL),
                '[]'
              ) AS contenido,
              COALESCE(
                (SELECT json_agg(json_build_object('tipo_ids', sub.tipo_ids, 'cantidad', sub.cantidad) ORDER BY sub.slot)
                 FROM (
                   SELECT slot, cantidad, array_agg(tipo_id ORDER BY tipo_id) AS tipo_ids
                   FROM paquete_inflables_incluidos
                   WHERE paquete_id = p.id
                   GROUP BY slot, cantidad
                 ) sub),
                '[]'
              ) AS inflables_incluidos
       FROM paquetes p
       LEFT JOIN paquete_items pi ON pi.paquete_id = p.id
       ${where}
       GROUP BY p.id
       ORDER BY p.brand, p.tipo, p.id`,
      values
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/paquetes/:id
router.get("/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = await getPaqueteWithItems(Number(req.params.id));
    if (!data) { res.status(404).json({ error: "Paquete not found" }); return; }
    res.json(data);
  } catch (err) {
    next(err);
  }
  /**
   * @swagger
   * /paquetes:
   *   get:
   *     summary: Listar paquetes (con contenido anidado)
   *     tags: [Paquetes]
   *     parameters:
   *       - in: query
   *         name: brand
   *         schema: { $ref: '#/components/schemas/Brand' }
   *     responses:
   *       200:
   *         content:
   *           application/json:
   *             schema:
   *               type: array
   *               items: { $ref: '#/components/schemas/Paquete' }
   */
});

// POST /api/paquetes
router.post("/", async (req: Request, res: Response, next: NextFunction) => {
  const client = await pool.connect();
  try {
    const { nombre, precio_unitario, tipo, brand, contenido, inflables_incluidos } = req.body;
    if (!nombre) {
      res.status(400).json({ error: "nombre is required" });
      return;
    }
    /**
     * @swagger
     * /paquetes/{id}:
     *   get:
     *     summary: Obtener paquete por ID
     *     tags: [Paquetes]
     *     parameters:
     *       - in: path
     *         name: id
     *         required: true
     *         schema: { type: integer }
     *     responses:
     *       200:
     *         content:
     *           application/json:
     *             schema: { $ref: '#/components/schemas/Paquete' }
     *       404:
     *         content:
     *           application/json:
     *             schema: { $ref: '#/components/schemas/Error' }
     */

    await client.query("BEGIN");

    const { rows } = await client.query(
      `INSERT INTO paquetes (nombre, precio_unitario, tipo, brand)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [nombre, precio_unitario ?? 0, tipo ?? "general", brand ?? "donofrio"]
    );
    const paquete = rows[0];

    if (Array.isArray(contenido) && contenido.length) {
      for (const item of contenido) {
        await client.query(
          `INSERT INTO paquete_items (paquete_id, producto_sku, producto_nombre, cantidad)
           VALUES ($1, $2, $3, $4)`,
          [paquete.id, item.producto_sku, item.producto_nombre, item.cantidad ?? 1]
        );
      }
    }

    if (inflables_incluidos !== undefined) {
      await setInflablesIncluidos(client, paquete.id, inflables_incluidos);
      /**
       * @swagger
       * /paquetes:
       *   post:
       *     summary: Crear paquete
       *     tags: [Paquetes]
       *     requestBody:
       *       required: true
       *       content:
       *         application/json:
       *           schema:
       *             type: object
      *             required: [nombre]
       *             properties:
       *               nombre:          { type: string }
       *               precio_unitario: { type: number }
       *               contenido:
       *                 type: array
       *                 items: { $ref: '#/components/schemas/PaqueteItem' }
       *     responses:
       *       201:
       *         content:
       *           application/json:
       *             schema: { $ref: '#/components/schemas/Paquete' }
       */
    }

    await client.query("COMMIT");
    const data = await getPaqueteWithItems(paquete.id);
    res.status(201).json(data);
  } catch (err) {
    await client.query("ROLLBACK");
    next(err);
  } finally {
    client.release();
  }
});

/**
 * @swagger
 * /paquetes/{id}:
 *   put:
 *     summary: Actualizar paquete (reemplaza contenido si se envía)
 *     tags: [Paquetes]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema: { $ref: '#/components/schemas/Paquete' }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema: { $ref: '#/components/schemas/Paquete' }
 */
// PUT /api/paquetes/:id
router.put("/:id", async (req: Request, res: Response, next: NextFunction) => {
  const client = await pool.connect();
  try {
    const id = Number(req.params.id);
    const { nombre, precio_unitario, tipo, brand, contenido, inflables_incluidos } = req.body;

    await client.query("BEGIN");

    const { rows } = await client.query(
      `UPDATE paquetes
       SET nombre          = COALESCE($1, nombre),
           precio_unitario = COALESCE($2, precio_unitario),
           tipo            = COALESCE($3, tipo),
           brand           = COALESCE($4, brand)
       WHERE id = $5 RETURNING *`,
      [nombre ?? null, precio_unitario ?? null, tipo ?? null, brand ?? null, id]
    );
    if (!rows.length) {
      await client.query("ROLLBACK");
      res.status(404).json({ error: "Paquete not found" });
      return;
    }

    if (Array.isArray(contenido)) {
      await client.query("DELETE FROM paquete_items WHERE paquete_id = $1", [id]);
      for (const item of contenido) {
        await client.query(
          `INSERT INTO paquete_items (paquete_id, producto_sku, producto_nombre, cantidad)
           VALUES ($1, $2, $3, $4)`,
          [id, item.producto_sku, item.producto_nombre, item.cantidad ?? 1]
        );
      }
    }

    if (inflables_incluidos !== undefined) {
      await setInflablesIncluidos(client, id, inflables_incluidos);
    }

    await client.query("COMMIT");
    const data = await getPaqueteWithItems(id);
    res.json(data);
  } catch (err) {
    await client.query("ROLLBACK");
    next(err);
  } finally {
    client.release();
  }
});

/**
 * @swagger
 * /paquetes/{id}:
 *   delete:
 *     summary: Eliminar paquete
 *     tags: [Paquetes]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 deleted: { type: integer }
 */
// DELETE /api/paquetes/:id
router.delete("/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { rows } = await pool.query(
      "DELETE FROM paquetes WHERE id = $1 RETURNING id",
      [req.params.id]
    );
    if (!rows.length) { res.status(404).json({ error: "Paquete not found" }); return; }
    res.json({ deleted: rows[0].id });
  } catch (err) {
    next(err);
  }
});

export default router;
